function ydot = pendolo(t,y)
ydot = [y(2); -sin(y(1))];
end