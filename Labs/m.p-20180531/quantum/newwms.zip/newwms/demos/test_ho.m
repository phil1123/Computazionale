% A test with 1D harmonic oscillator
function q = test_ho(nx,dt)

narginchk(2,2);

q = basesys1D(nx,1);
x = q.grid.x;
q.psi = exp(-0.5*x.^2);
q.V = @(x)x.^2/2;

q.run.dt = dt;
q.show.what{1} = 'abs(psi).^2';
q.show.what{2} = 'real(psi)';
q.show.V = [1;1];
q.show.ylim = [0 1;-1 1];

q = translate(q,-4);

disp('press any key to start evolution')
pause
evolve(q,10);
