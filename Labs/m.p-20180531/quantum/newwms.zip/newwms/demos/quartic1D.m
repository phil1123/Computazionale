% An example with the 1D quartic anharmonic oscillator
function q = quartic1D(lam,nx,nw)

narginchk(0,3);
if nargin < 3
	nw = 1;
end
if nargin < 2
	nx = 256;
end
if nargin == 0
	lam = 0.25;
end

q = basesys1D(nx,nw);
x = q.grid.x;
sx = (1/nw)*(1:nw);
q.psi = exp(-0.5*(x*(1./sx)).^2);
q.V = @(x)x.^2/2+lam*x.^4/4;
%q.V = x.^2/2+lam*x.^4/4;

q.show.what{1} = 'abs(psi).^2';
q.show.what{2} = 'real(psi)';
q.show.V = [1;1];
q.show.ylim = [0 1;-1 1];

a = linspace(q.grid.box(1)/3,q.grid.box(2)/3,nw);
q = translate(q,a);

disp('press any key to start evolution')
pause
evolve(q,10);
