function cm = constantmag(B,bx,by)

if nargin < 3, by = 0;  end
if nargin < 2, bx = 8;  end
if nargin < 1, B = 0.8; end

%cm = basesys(256,256);
cm = basesys(512,512);
%cm = basesys(1024,1024);
addmagfield(cm,B);

B = cm.mag.B(1,1);
disp(['fixing constant B to = ',sprintf('%0.12f',B)])
disp(['Dirac quantization integer = ',num2str(cm.mag.ndirac)])
cm.show.what = {'real(psi)'};

if bx > 0
	disp (['boosting k_x by ',num2str(bx)]);
end
if by > 0
	disp (['boosting k_y by ',num2str(by)]);
end
boost(cm,bx,by);
view(2)
axis square

if nargin > 0
	return
end

disp('press any key to start evolution')
pause
evolve(cm,4*pi/B);

disp ('press any key to boost more');
pause
disp ('boosting k_x by another 8');
boost(cm,8,0);
disp('press any key to start evolution')
pause
evolve(cm,4*pi/B);

disp ('press any for another example');
pause
cm = constantmag(0.6,0,20);
B = cm.mag.B(1,1);
disp(['fixing constant B to = ',sprintf('%0.12f',B)])
disp(['Dirac quantization integer = ',num2str(cm.mag.ndirac)])
disp('boosting k_y by 20')
disp('press any key to start evolution')
pause
evolve(cm,4*pi/cm.mag.B(1,1));

% % PERIODIFICATION IS USELESS! 
% L = cm.grid.box([2,4]) - cm.grid.box([1,3]);
% x = cm.grid.x;
% y = cm.grid.y;
% cm.psi = zeros(size(x));
% for j = -3:3
% 	for k = -3:3
% 		psi = exp(-(x+j*L(1)).^2/2 - (y+k*L(2)).^2/2);
% 		disp(num2str(max(psi(:))))
% 		cm.psi = cm.psi + psi;
% 	end
% end
   
