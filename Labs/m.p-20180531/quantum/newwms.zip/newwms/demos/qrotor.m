function qr = qrotor(nm)

if nargin == 0
	nm = 5;
end
qr = basesys(256,256);
x = qr.grid.x;
y = qr.grid.y;
[~,r] = cart2pol(x,y);
qr.V = 0.15*r.*r;
qr.psi = polar_harmonic(qr,2,nm).*exp(-r/3);
qr.show.n = 1;	
disp(qr)
show(qr)
view(2)
disp('.....')
disp('using private colormap and 2D view')
disp('press any key to start evolution')
pause
evolve(qr,10.5);
assignin('base','qr',qr);
disp('.....')
disp('press any key to continue evolution')
disp('using matlab default colormap and 3D view')
pause
view(3)
colormap parula
evolve(qr,7.5);
disp('.....')
disp('press any key to continue evolution')
disp('using winter colormap')
pause
colormap winter
evolve(qr,5);
% disp('.....')
% disp('press any key to continue evolution')
% disp('resetting internal state of show.m to revert to qr.show.colormap')
% pause
% show([]) % reset internal state
% evolve(qr,5);
