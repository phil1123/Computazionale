pr = basesys(256,256);
ksmearing = @(kx,ky) exp(-kx.*kx/2 - ky.*ky/2); 
pr.psi = frandn(pr,ksmearing);
show(pr)
disp('press any key to start evolution')
pause
evolve(pr,20);
