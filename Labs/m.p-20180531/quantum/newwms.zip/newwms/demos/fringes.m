function fr = fringes

box = [-60,60,-40,40];   % the 2D box
N = [512, 256];          % the grid numbers
mass = [1.0, 1.0];       % the particle(s) mass(es) 
dt = 0.025;              % the characteristic timestep
BC = [0, 0];             % the boundary conditions, 0=PBC, 1=DBC
wshow =  {'real(psi)'};  % what to show in the figures
nshow = 4;               % show every nshow timesteps

fr.grid = mkgrid(N,box,BC);
fr.mass = mass;
fr.run.dt = dt;
fr.run.t = 0;
fr.V = 10*(1-1i)*twoslit(fr,0,8,2,8);
fr.V = fr.V - 50*1i*rectanglarea(fr,box(1),box(3),box(1)+1,box(4));
sx = 2; sy = 8;
x = fr.grid.x;
y = fr.grid.y;
fr.psi = exp(-x.^2/(4*sx*sx) - y.^2/(4*sy*sy));
disp(fr)
fr.show.what = wshow;
fr.show.n = nshow;
fr.show.cfactor = 1;
show(fr)
view(-18,35)
disp('press any key to boost wavefunction')
pause
boost(fr,4,0);
disp('press any key to translate wavefunction')
pause
translate(fr,-30,0);
fr.record.pdf.ndt = 8;
fr.record.pdf.expr = 'abs(psi).^2'; 
disp('press any key to start evolution')
pause
evolve(fr,20);
disp('press any key to zoom color map')
pause
fr.show.cfactor = 0.5;
show(fr)
view(-18,35)
disp('press any key to replay recorded data')


