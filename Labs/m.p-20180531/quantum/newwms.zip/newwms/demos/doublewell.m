% An example with the 1D quartic double well
function dw = doublewell(g,nx)

narginchk(0,2);
if nargin < 2
	nx = 512;
end
if nargin < 1
	g = 0.225;
end

box = [-2.5,2.5];        % the 1D box
N = [nx,1];              % grid number and number of wavefunctions
mass = 1/g;              % the particle mass
dt = 0.001;              % the characteristic timestep
BC = 0;                  % the boundary conditions, 0=PBC, 1=DBC

dw.grid = mkgrid(N,box,BC);
dw.mass = mass;
x = dw.grid.x;
dw.V = (1/2/g)*(x.^2-1).^2;
%Vharm = 4*(1/2/g)*(x-1).^2;
dw.psi = exp(-(x-1).^2/g);
dw.run.dt = dt;

dw.show.what{1} = 'abs(psi).^2';
dw.show.n = 10;
dw.show.V = 0.5;
dw.show.ylim = [0,1.5];
show(dw)

if nargout == 0
    disp('press any key to start evolution')
    pause
    evolve(dw,110);
else
    disp('enter evolve(sysname,timespan) to evolve system')
end
