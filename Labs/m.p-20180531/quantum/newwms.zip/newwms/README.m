% To start using this package, run this file as a Matlab script

disp('adding new commands to the command path...')
addpath(genpath(pwd))
rmpath([pwd,'/playarea'])
rmpath([pwd,'/devel'])

disp('Available demo scripts in demos/ subdirectory:')
dir demos/*.m

disp('command functions in utils/ subdirectory:')
dir utils/*.m

disp('command functions in action/ subdirectory:')
dir actions/*.m

disp('command functions in evolution/ subdirectory:')
dir evolution/*.m
