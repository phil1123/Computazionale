function hu = husimi(kappa,u)

    global x kx ky psi
    if nargin == 1
        u = psi;
    end
    
    u = fft(exp(-1i*x.*ky).*u.');
    u = ifft(u.*exp(-kx'.^2/2/kappa));
    hu = sqrt(size(psi,1)*pi/kappa).*abs(u).^2;
	hu = hu';
    
