function Qn = qmoyal(n,t)

    global x y ky psi
    
    up = (y == x/2);
    evolve
    um = (y == -x/2);
    
    ifft(exp(+i*ky.*x/2).*u);
    um = ifft(exp(-i*ky.*x/2).*u);
    u = up.*conj(um);
    wu = sfft(u.').';

%% nested private function

    function onestep_1D
        %N.B.: the active 1-space is along the columns (y coordinate)
        psi = fft(psi);
        psi = ifft(psi.*Wy);
        psi = psi.*U;
        if flag > 0
            renproj_;
        end
    end

end
