function psi = project(sys,psi)
% project(sys) projects sys.psi over the linear complement of 
% the wavefunctions in the cell array sys.store.psi; 
% ppsi = project(u,psi) does the same over a generic psi. 

narginchk(1,2);
sysname = inputname(1);
if nargin == 1
	psi = sys.psi;
end

u = zeros(size(psi));
for j = 1:length(sys.store.psi)
	v = sys.store.psi{j};
	c = v(:)'*psi(:);
	u = u + c*v;
end
psi = psi - u;

if nargout == 0
	sys.psi = psi;
	assignin('caller',sysname,sys);
end
