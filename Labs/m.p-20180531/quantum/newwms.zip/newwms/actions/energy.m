function E = energy(u)

    global kx ky mass psi V
    
    if nargin == 0
        u = psi;
    end
    
    E = 0.5*evpq(kx.*kx,u)/mass(1);
    E = E + 0.5*evqp(ky.*ky,u)/mass(2);
    E = E + evqq(V,u);