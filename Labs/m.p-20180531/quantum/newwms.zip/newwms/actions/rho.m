function g = rho(u)
% rho returns the normalized probability propto abs(psi)^2;
% g = rho(u) does the same for the generic u.

    global psi
    
    if nargin == 0
        u = psi;
    end

    g = abs(u).^2;
    g = g/sum(g(:));
