function j = Jphi(f)

    global x y psi
    if nargin == 0
        u = psi;
    else
        u = f;
    end
    
    r = sqrt(x.*x + y.*y);
    j = x.*jy(u) - y.*jx(u);
    j = j./(r+eps);