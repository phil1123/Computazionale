function [f,gr] = fourier(sys,f)

narginchk(1,2);
sysname = inputname(1);
if nargin == 1
        f = sys.psi;
end

gr = addskwn(sys.grid);
D = length(gr.box)/2;
if D == 2
	[ny,nx] = size(f);
	f = exp(1i*(nx-1)*kx/2 + 1i*(ny-1)*ky/2).*fft2(f);
    f = (1/sqrt(nx*ny))*fftshift(f);
	gr.kx = fftshift(gr.kx);
	gr.ky = fftshift(gr.ky);
else
	nx = size(f,1);
	f = (1/sqrt(nx))*fftshift(exp(1i*(nx-1)*gr.k/2).*fft(f));
	gr.k = fftshift(gr.k);
end

if nargout == 0
	sys.psi = f;
	assignin('caller',sysname,sys);
end
