function sys = translate(sys,ax,ay)
% if D=2, translate(sys,ax,ay) translates sys.psi by (ax,ay);
% if D=1, use translate(sys,ax).
% tsys = translate(sys,ax,(ay)) assign translated sys.psi to tsys

	narginchk(2,3);
	sysname = inputname(1);
	box = sys.grid.box;
	D = length(box)/2;
	psi = sys.psi;
	
	if D == 1
		if nargin == 3
			warning('ignoring second translation argument');
		end
		L = box(2)-box(1);
		[Nx,Nw] = size(psi);
		dx = L/Nx;
		if isscalar(ax)
			ax = ax*ones(1,Nw);
		elseif length(ax) ~= Nw
			error('there must be as many translation parameters as wavefunctions');
		end
		nx = mod(round(ax/dx),Nx);
		for j = 1:length(nx)
			Ix = [nx(j)+1:Nx,1:nx(j)];
			sys.psi(:,j) = psi(Ix,j);
		end
	else
		if nargin == 2
			warning('missing translation parameter in y direction, assuming zero');
			ay = 0;
		end
		Lx = box(2)-box(1);
		Ly = box(4)-box(3);
		[Ny,Nx] = size(psi);
		dx = Lx/Nx; dy = Ly/Ny;
		nx = mod(round(ax/dx),Nx);
		ny = mod(round(ay/dy),Ny);
		Ix = [Nx-nx+1:Nx,1:Nx-nx];
		Iy = [Ny-ny+1:Ny,1:Ny-ny];
		%Iy = [ny+1:Ny,1:ny];
		if isfield(sys,'mag') && nnz(sys.mag.B) > 0
			% N.B.: x- and y-translations do not commute when B~=0.
			% Here we do x-translation first.
			U = exp(1i*sys.mag.gfun);
			psi = U.*psi;
			psi = psi(:,Ix);
			psi = psi./U./U;
			psi = psi(Iy,:);
			psi = U.*psi;
		else
			psi = psi(Iy,Ix);
		end
		sys.psi = psi;
	end
	
	if nargout == 0
		% act on input sys
		assignin('caller',sysname,sys);
	end
	
	if isfield(sys,'show')
		show(sys);
	end

