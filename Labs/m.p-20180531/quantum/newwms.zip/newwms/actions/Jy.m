function j = Jy(u)
% Jy returns the y component of the current of the global psi;
% j = Jy(u) give that of a generic u.

    global mass psi ky A
   
    if nargin == 0
        u = psi;
    end
    
    v = ky.*fft(u);
    v = ifft(v);
    j = conj(u).*(v - A.y.*u);
    j = real(j)/mass(2);