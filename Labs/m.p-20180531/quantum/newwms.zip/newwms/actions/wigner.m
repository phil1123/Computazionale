function [w,sys] = wigner(sys)
% w = wigner(sys) computes the Wigner function w od a 1D sys, or just
% extract sys.w if present in sys.
% [w,usys] = wigner(sys) copies w to usys.w and modifies usys to allow 
% for 2D plotting of w.

	if isfield(sys,'w')
		w = sys.w;
		return;
	end
	box = sys.grid.box;
	D = length(box)/2;
	psi = sys.psi;
	if D == 2
		error('Wigner function can be computed only in D = 1');
	end
	[nx,nw] = size(psi);	
	if nw ~= 1 
		error('only one wavefunction allowed');
	end
	x = sys.grid.x;
	if (size(x,2)) == nx;
		x = x(1,:);
	else
		x = x';
	end
	dx = x(2)-x(1);
	kx = (1/dx) * skwavenums(nx)';
	
    u = fft(psi)*ones(1,nx);
    up = ifft(exp(+1i*kx*x/2).*u);
    um = ifft(exp(-1i*kx*x/2).*u);
    u = up.*conj(um);
    w = real(sfft(u.'));

	if nargout == 2
		sys.w = w;
		kx = unskew(kx);
		[x,kx] = meshgrid(x',kx);
		sys.grid.x = x;
		sys.grid.y = kx;
		sys.show.D = 2;
		sys.show.what{1} = 'wigner(sys)';
	end
