function pf = pyhatn(n,f)

    global kx psi
    
    if nargin == 0
        n = 1;
    end
    
    if nargin <= 1
        f = psi;
    end

    pf = ky.^n .* fft(f);
    pf = ifft(pf);