function pf = pxhatn(n,f)

    global kx psi
    
    if nargin == 0
        n = 1;
    end
    
    if nargin <= 1
        f = psi;
    end

    pf = (kx.').^n .* fft(f.');
    pf = ifft(pf).';