function j = Jx(u)
% Jx returns the x component of the current of the global psi;
% j = Jx(u) give that of a generic u.

    global mass psi kx A
    
    if nargin == 0
        u = psi;
    end

    v = kx.*fft(u.').';
    v = ifft(v.').';
    j = conj(u).*(v - A.x.*u);
    j = real(j)/mass(1);