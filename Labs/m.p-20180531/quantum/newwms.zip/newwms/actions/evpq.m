function eX = evpq(X,f)

    global psi
    
    if nargin == 1
        u = psi;
    else
        u = f;
    end

    rho = abs(fft(u.').').^2;
    eX = sum(sum(X.*rho))/sum(rho(:));
