function tf = translate(ax,ay,f)

    global kx ky psi B A
    
    if nargin == 2
        u = psi;
    else
        u = f;
    end
    
    u = fft2(u);
    u = ifft2(u.*exp(-i*(ax*kx + ay*ky)));
    if nnz(B) > 0
        u = u.*exp(-i*(ax*A.x + ay*A.y));
    end
    
    if nargin == 2
        psi = u;
        show
    else
        tf = u;
    end