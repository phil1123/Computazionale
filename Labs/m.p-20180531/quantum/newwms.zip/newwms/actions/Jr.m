function j = Jr(f)

    global x y psi
    if nargin == 0
        u = psi;
    else
        u = f;
    end
    
    r = sqrt(x.*x + y.*y);
    j = x.*Jx(u) + y.*Jy(u);
    j = j./(r+eps);