function sys = boost(sys,vx,vy)
% if D=2, boost(sys,vx,vy) boosts sys.psi by velocities (vx,vy);
% if D=1, use boost(sys,vx)
% bsys = boost(sys,vx,vy) assign boosted sys.psi to bsys

narginchk(2,3);
sysname = inputname(1);
box = sys.grid.box;
D = length(box)/2;
psi = sys.psi;
m = sys.mass;
x = sys.grid.x;

if D == 2
	if nargin == 2
		error('missing boost velocity in y direction');
	end
	y = sys.grid.y;
	L = box([2,4])-box([1,3]);
	vx = round(vx*L(1)/2/pi)*2*pi/L(1);
	vy = round(vy*L(2)/2/pi)*2*pi/L(2);
	sys.psi = psi.*exp(1i*m(1)*vx*x + 1i*m(2)*vy*y);
else
	if nargin == 3
		warning('ignoring second boost argument');
	end
	L = box(2)-box(1);
	N = size(psi);
	if isscalar(vx)
		vx = vx*ones(1,N(2));
	elseif length(vx) ~= N(2)
		error('there must be as many boost velocities as wavefunctions');
	end
	vx = round(vx*L(1)/2/pi)*2*pi/L(1);
	sys.psi = psi.*exp(1i*m(1)*x*vx);
end

if nargout == 0
	assignin('caller',sysname,sys);
end

if isfield(sys,'show')
	show(sys);
end
