function [u,d] = diagonalize(n,Afun)

    global y kx ky mass V
    if nargin == 1
        Afun = @hamiltonian;
    end
    
    [nr,nc] = size(y);
    k2 = 0.5*(kx.^2/mass(1) + ky.^2/mass(2));
    opts.issym = 1;
    opts.disp = 0;
    [u,d] = eigs(Afun,nr*nc,n,'sa',opts);
    d = diag(d);

    function hf = hamiltonian(f)
        f = reshape(f,nr,nc);
        hf = fft2(f);
        hf = ifft2(k2.*hf);
        hf = hf + V.*f;
        hf = reshape(hf,nr*nc,1);
    end

end
