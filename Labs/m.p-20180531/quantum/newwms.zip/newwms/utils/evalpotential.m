function V = evalpotential(sys)

box = sys.grid.box;
D = length(box)/2;
if isa(sys.V,'function_handle')
	if D == 1
		V = sys.V(sys.grid.x);
	else
		V = sys.V(sys.grid.x,sys.grid.y);
	end
else
	V = sys.V;
end
