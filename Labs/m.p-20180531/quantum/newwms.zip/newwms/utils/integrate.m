function F = integrate(z,f)

    nr = size(f,1);
    a = z(2,1)-z(1,1);
    F = a*(cumtrapz(f) - ones(nr,1)*trapz(f(1:floor(nr/2),:)));
    %F = fftinteg(z,f,1);