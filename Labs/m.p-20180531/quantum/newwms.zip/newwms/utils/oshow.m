function show(sys,sysname,arr)
% TODO: movies

%% prep stage

persistent gdata
if nargin == 1 || isempty(sysname)
	sysname = inputname(1);
end

% reset gdata explicitly
if nargin == 1 && isempty(sys)
	gdata = [];
	return;
end
	
if ~isfield(sys,'show')
	error('missing ''show'' field in input system!');
end
if nargin < 3 && (~isfield(sys.show,'what') || isempty(sys.show.what))
	error('nothing to show')
end

psi = sys.psi;
V = real(evalpotential(sys));
x = sys.grid.x;
if isfield(sys.show,'D')
	D = sys.show.D;
else
	D = length(sys.grid.box)/2;
end
if D == 2
	y = sys.grid.y;
	init_ = @init_2D;
	show_ = @show_2D;
else
	init_ = @init_1D;
	show_ = @show_1D;
	showV = 0;
	if isfield(sys.show,'V') && sys.show.V
		showV = sys.show.V;
	end
	yl = [];
	if isfield(sys.show,'ylim')
		yl = sys.show.ylim;
	end
end
wshow = sys.show.what;
cmap = [];
if isfield(sys.show,'colormap') && ~isempty(sys.show.colormap)
	cmap = sys.show.colormap;
end
cfactor = 1;
if isfield(sys.show,'cfactor') && ~isempty(sys.show.cfactor)
	cfactor = sys.show.cfactor;
end

% (re)init gdata
init = isempty(gdata) || ~isfield(gdata,sysname);
if init || ~isvalid(gdata.(sysname).hi(1)) ...
		|| ~isequal(gdata.(sysname).hi.Parent,gca) ...
		|| (~isempty(cmap) && ~isequal(gdata.(sysname).colormap,cmap)) ...
		|| ~isequal(gdata.(sysname).cfactor,cfactor) ...
		|| ~isequal(gdata.(sysname).size,size(x))
	gdata.(sysname) = initshow(cmap);
end
gs = gdata.(sysname);

if isfield(sys.run,'t') 
	t = sys.run.t;
elseif isfield(sys.run,'tspan') && ~isscalar(sys.run.tspan)
	t = sys.run.tspan(1);
else 
	t = 0;
end

%% main

if nargin < 3
	show_(wshow{1},gs.hi)
	if length(wshow) >= 2 && ~isempty(wshow{2})
	% as of now, this applies only to D=2
	% TODO: multiple plots for D=1
		show_(wshow{2},gs.hi(2))
	end
else
	show_(arr,gs.hi(1))
end

set(gs.ht,'String',['t = ',num2str(t)]);


%% nested private functions

	function show_1D(f,h)
		g = f;
		if ischar(f)
            g = zeros(size(psi));
            eval(['g=', f,';']);
		end
		for jh = 1:length(h)
			set(h(jh),'Ydata',g(:,jh));
		end
		axis manual
		drawnow      
	end

    function show_2D(f,h)
		g = f;
		if ischar(f)
			eval(['g=', f,';']);
		end
		set(h,'ZData', g)
		axis manual
		caxis manual
		drawnow
	end

	function gs = initshow(cmap)
		if isempty(cmap)
			cmap = mycolormap; % the private colormap
		end
		gs.colormap = cmap;
		gs.cfactor = cfactor;
		gs.size = size(x);
		nfig = 1;
		if length(wshow) > 1 && ~isempty(wshow{2})
			nfig = 2;
		end
		gs.hi = init_(nfig,cmap);
		gs.ht = text('Units','normalized','Position', ...
			[0,1.02],'String','t = 0');
	end

	function h = init_1D(~,~)
		%handle the 1D case through plot
		if showV > 0
			Vlim = [min(V),showV*max(V)];
			hV = axes('position',[0.06,0.06,0.86,0.9],'ylim',Vlim,'Xtick',[],...
				'XAxisLocation','top','YAxisLocation','right');
			hold(hV,'on')
			plot(hV,x,V,'k--');
			ha = axes('position',[0.06,0.06,0.86,0.9],'color','none');
			hold(ha,'on')
		else
			ha = axes('position',[0.06,0.06,0.9,0.9],'box','on');
		end
		f = 0;
		eval(['f=', wshow{1},';']);
		h = plot(ha,x,f);
		if ~isempty(yl)
			ylim(ha,yl)			
		end
		axis(ha,'manual')
		drawnow
	end

	function h = init_2D(n,cmap)
		bottom = 0.05;
		width = 0.9/n;
		height = 0.92;
		for j = 1:n
			f = zeros(size(x));
			eval(['f=', wshow{j},';']);
			left = 0.065+(j-1)*(width+0.02);
			hp = subplot('Position',[left bottom width height]);
			if ~isempty(cfactor) && nnz(f) > 0
				cmin = cfactor*min(f(:));
				cmax = max(abs(cmin),cfactor*max(f(:)));
				cmin = -cmax;
			end
			h(j) = surf(x,y,f); %#ok<AGROW>
			shading interp;
			axis tight
			if init
				set(hp,'Zlim',[cmin cmax]);
			end
			colormap(cmap);
			caxis(hp,[cmin cmax]);
			drawnow
		end
	end

end

function cmap = mycolormap
	o = 65;
	ca = linspace(0.3,1,o-1)';
	cb = linspace(0,1,o-1)';
	c = [ca,cb,linspace(0,0.5,o-1)'];
	cmap = [flipud(c);[0,0,0];[zeros(o-1,1),cb,ca]];
end
