function replay(sys,direction)

if nargin == 1
	direction = 1;
end
d = sign(direction);
if d == 0
	error('no time direction chosen')
end

fnames = fieldnames(sys.record);

for j = 1:length(fnames)
	name = fnames{j};
	obs = sys.record.(name);
	if d > 0
		It = 1:length(obs.t);
	else
		It = length(obs.t):-1:1;
	end
	ndim = nnz(size(obs.values) > 1) - 1;
	if ndim == 2
		for jt = It
			show(sys,obs.values(:,:,jt))
		end
	elseif ndim == 1
		for jt = It
			show(sys,obs.values(:,jt))
		end			
	else
		plot(obs.t,obs.values)
	end
end
