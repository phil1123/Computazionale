function sys = addmagfield(sys,B)
     
%% prep

narginchk(1,2);
sysname = inputname(1);	
box = sys.grid.box;
D = length(box)/2;
if D ~= 2
	error('magnetic field is allowed only in D=2')
end
L = box([2,4])-box([1,3]);
x = sys.grid.x;
y = sys.grid.y;
[ny,nx] = size(x);    
if isscalar(B)
	B = B*ones(ny,nx);
end

%% main

Bo = sum(B(:))/(nx*ny);
Bs = B - Bo;
if norm(Bs) < 1e-10
	Bs = 0;
end
ndirac = round(Bo*L(1)*L(2)/2/pi);
Bo = 2*pi*ndirac/L(1)/L(2);
A.ox = -0.5*Bo*y;
A.oy = 0.5*Bo*x;
A.x = A.ox - 0.5*integrate(y,Bs);
Asy = 0.5*integrate(x.',Bs.').';
A.y = A.oy + Asy;
gfun = A.ox.*x  + integrate(y,Asy);

sys.mag.A = A;
sys.mag.ndirac = ndirac;
sys.mag.B = Bo + Bs;
sys.mag.gfun = gfun;
		
if nargout == 0
	assignin('caller',sysname,sys);
end
