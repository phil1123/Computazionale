function gr = addskwn(gr)

D = length(gr.box)/2;
if D == 2
	N = fliplr(size(gr.x));
	L = gr.box([2,4])-gr.box([1,3]);
	kx = (N(1)/L(1)) * skwavenums(N(1));
	ky = (N(2)/L(2)) * skwavenums(N(2));
	[gr.kx,gr.ky] = meshgrid(kx,-ky);
else
	N = size(gr.x,1);
	L = gr.box(2)-gr.box(1);
	k = (N/L) * skwavenums(N);
	gr.k = k'*ones(1,size(gr.x,2));
end
