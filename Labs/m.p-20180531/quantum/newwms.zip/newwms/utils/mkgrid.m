function gr = mkgrid(N,box,BC)

x = linspace(box(1),box(2),N(1)+1);
dx = x(2)-x(1);
x = x(1:N(1)) + dx/2;
if length(box) == 4
	y = linspace(box(3),box(4),N(2));
	dy = y(2)-y(1);
	y = y(1:N(2)) + dy/2;
	[x,y] = meshgrid(x,y);
else
	x = x';
end

gr.box = box;
gr.x = x;
if length(box) == 4
	gr.y = y;
end

if nargin == 2
	gr.BC = zeros(size(box)/2);
else
	gr.BC = BC;
end
