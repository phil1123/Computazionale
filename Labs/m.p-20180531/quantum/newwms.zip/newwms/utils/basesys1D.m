function sys = basesys1D(nx,nw)
% sys = basesys1D(nx,nw) produces a basic 1D system with nx points 
% and nw wavefunctions.
% DO NOT change this file or some demo might stop working properly.
% To change setup, either modify the output of this function or edit and
% rename a copy of it.

box = [-12,12];          % the 1D box
N = [nx, nw];            % grid number and number of wavefunctions
mass = 1;                % the particle mass
dt = 0.001;              % the characteristic timestep
BC = 0;                  % the boundary conditions, 0=PBC, 1=DBC
wshow =  {'real(psi)'};  % what to show in the figures
nshow = 10;              % show every nshow timesteps
wrecord = {''};          % do not record anything
V = zeros(size(N));

sys.grid = mkgrid(N,box,BC);
sys.mass = mass;
sys.V = V;

% base 1D system has unnormalized Gaussian psi's
x = sys.grid.x*ones(1,nw);
sx = 2*ones(nx,1)*(1:nw)/nw;
sys.psi = exp(-x.^2./sx./sx/4);

sys.run.dt = dt;
sys.run.t = 0;
if ~isempty(wshow{1})
	sys.show.what = wshow;
	sys.show.n = nshow;
	sys.show.D = 1;
end
if ~isempty(wrecord{1})
	sys.record.what = wrecord;
	sys.record.n = nrecord;
end


