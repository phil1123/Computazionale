function k = skwavenums(N)
% k = skwavenums(N) calculates skewed 1-D wavenumbers 
    n = floor(N/2);
    nn = floor((N-1)/2);
    k = (2*pi/N)*[0:nn,-n:-1];