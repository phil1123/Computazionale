function z = unskew(skz)

    [nr,nc] = size(skz);
    n = floor([nr,nc]/2);
    nn = ceil([nr+1,nc+1]/2);
    z = skz([nn(1):nr,1:n(1)],[nn(2):nc,1:n(2)]);
