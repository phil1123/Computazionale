function show(sys,other)
% TODO: movies

%% prep stage

narginchk(1,2);
sysname = inputname(1);

if nargin == 1
	if ~isfield(sys,'show') || ~isfield(sys.show,'what') || isempty(sys.show.what)
		warning('missing ''show'' field in input system, adding default ''real(psi)''');
		sys.show.what = {'real(psi)'};
		assignin('caller',sysname,sys);
	end
elseif ischar(other) && ~isfield(sys,other)
	error(['no field ',other,' in ',sysname'])
elseif ~isnumeric(other)
	error(['wrong type, cannot show ',inputname(2)])
end

wshow = sys.show.what;
nfig = length(wshow);
if nfig > 4 
	warning('showing only first four items in show.what')
	nfig = 4;
end

psi = sys.psi; %#ok<NASGU>
V = real(evalpotential(sys));

x = sys.grid.x;
if isfield(sys.show,'D')
	D = sys.show.D;
else
	D = length(sys.grid.box)/2;
end
if D == 2
	y = sys.grid.y;
	init_ = @init_2D;
	show_ = @show_2D;
else
	init_ = @init_1D;
	show_ = @show_1D;
	showV = zeros(nfig,1);
	if isfield(sys.show,'V')
		showV(1:length(sys.show.V)) = sys.show.V; 
	end
	yl = zeros(nfig,2);
	if isfield(sys.show,'ylim')
		yl(:,1:length(sys.show.ylim)) = sys.show.ylim; 
	end
end

cfactor = 1;
if isfield(sys.show,'cfactor') && ~isempty(sys.show.cfactor)
	cfactor = sys.show.cfactor;
end

% (re)init
if nargin == 1
	h = -ones(nfig,1);
	if isfield(sys.show,'h')
		h = sys.show.h;
	end
	flag = 0;
	for j = 1:nfig
		if ~ishghandle(h(j,1))
			sys.show.h(j,:) = initshow(j);
			flag = 1;
		end
	end
	if flag
		sys.show.ht = initshow(0);
		assignin('caller',sysname,sys);
	end
	h = sys.show.h;
	ht = sys.show.ht;
else
	h = initshow(nfig+1);
end

if isfield(sys.run,'t') 
	t = sys.run.t;
elseif isfield(sys.run,'tspan') && ~isscalar(sys.run.tspan)
	t = sys.run.tspan(1);
else 
	t = 0;
end

%% main

if nargin == 1
	for j = 1:length(wshow)
		show_(wshow{j},h(j,:))
		set(ht,'String',['t = ',num2str(t)]);
	end
else
	show_(other,h)
end


%% nested private functions

	function show_1D(f,h)
		g = f;
		if ischar(f)
            eval(['g=', f,';']);
		end
		%figure(h(1).Parent.Parent);
		for jh = 1:length(h)
			set(h(jh),'Ydata',real(g(:,jh)));
		end
		drawnow      
	end

    function show_2D(f,h)
		g = f;
		if ischar(f)
			eval(['g=', f,';']);
		end
		figure(h.Parent.Parent);
		set(h,'ZData', real(g))
		drawnow
	end

	function h = initshow(k)
		pos34 = [0.28 0.44];
		pos234 = [0.55 pos34];
		if nfig == 1
			pos = [0.5 pos234];
		elseif nfig == 2
			pos(1,:) = [0.39 pos234];
			pos(2,:) = [0.67 pos234];
		elseif nfig >= 3
			pos(1,:) = [0.16 pos234];
			pos(2,:) = [0.44 pos234];
			pos(3,:) = [0.72 pos234];			
			if nfig == 4
				pos(4,:) = [0.72 0.11 pos34];			
			end
		end
		if k == 0
			h = text('Units','normalized','Position', ...
				[0.01,1.02],'String','t = 0');
			return;
		end
		if k <= nfig
			f = wshow{k};
		else
			f = other;
			k = 1;
		end
		g = f;
		if ischar(f)
			eval(['g=', f,';']);
		end
		figure('Units','normalized','Outerposition',pos(k,:))
		h = init_(g,k);
	end

	function h = init_1D(f,k)
		% handle the 1D case through plot;
		% alternative for double y axis: plotyy
		if showV(k) > 0
			Vlim = [min(V),showV(k)*max(V)];
			hV = axes('position',[0.06,0.06,0.86,0.9],'ylim',Vlim,'Xtick',[],...
				'XAxisLocation','top','YAxisLocation','right');
			hold(hV,'on')
			plot(hV,x,V,'k--');
			hf = axes('position',[0.06,0.06,0.86,0.9],'color','none');
			hold(hf,'on')
		else
			hf = axes('position',[0.06,0.06,0.9,0.9],'box','on');
		end
		h = plot(hf,x,f);
		if ~(all(yl(k,:)) == 0)
			ylim(hf,yl(k,:))			
		end
		axis(hf,'manual')
		drawnow
		hold on
	end

	function h = init_2D(f,~)
		ha = axes('Position',[0.065 0.06 0.9 0.92]);
		if nnz(f) > 0
			cmin = cfactor*min(f(:));
			cmax = max(abs(cmin),cfactor*max(f(:)));
			cmin = -cmax;
			set(ha,'Zlim',[cmin cmax]);
			caxis(ha,[cmin cmax]);
		end
		h = surf(x,y,f);
		shading interp;
		axis tight manual
		caxis manual
		colormap(mycolormap);
		drawnow
		hold on
	end

end

function cmap = mycolormap
	o = 65;
	ca = linspace(0.3,1,o-1)';
	cb = linspace(0,1,o-1)';
	c = [ca,cb,linspace(0,0.5,o-1)'];
	cmap = [flipud(c);[0,0,0];[zeros(o-1,1),cb,ca]];
end
