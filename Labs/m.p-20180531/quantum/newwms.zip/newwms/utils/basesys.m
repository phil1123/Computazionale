function sys = basesys(nx,ny)
% sys = basesys(nx,ny) produces a basic 2D system with nx*ny points.
% DO NOT change this file or some demo might stop working properly.
% To change setup, either modify the output of this function or edit and
% rename a copy of it.

box = [-16,16,-16,16];   % the 2D box
N = [ny, nx];            % the grid numbers. N.B.: 1==x==row index, 2==y==column index
mass = [1.0, 1.0];       % the particle(s) mass(es) 
dt = 0.025;              % the characteristic timestep
BC = [0, 0];             % the boundary conditions, 0=PBC, 1=DBC
wshow =  {'real(psi)'};  % what to show in the figures
nshow = 4;               % show every nshow timesteps
V = zeros(N(2),N(1));

sys.grid = mkgrid(N,box,BC);
sys.mass = mass;
sys.V = V;

% base system has an unnormalized Gaussian psi
sys.psi = exp(-sys.grid.x.^2/2 - sys.grid.y.^2/2);

sys.run.dt = dt;
sys.run.t = 0;
if ~isempty(wshow{1})
	sys.show.what = wshow;
	sys.show.n = nshow;
end


