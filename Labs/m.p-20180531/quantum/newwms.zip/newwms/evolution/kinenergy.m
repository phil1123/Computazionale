function [Kx,Ky] = kinenergy(px,py,mass)

    %galileian
    Kx = 0.5*px.*px/mass(1);
    Ky = 0.5*py.*py/mass(2);
    
    %relativistic cannot be done with the magnetic field
    c = 1;
    %K = c*sqrt(p.*p + mass^2*c^2);
