function sys = evolve(sys,t)
% Time evolver for wms in D=1 and D=2 (gauge-invariant in
% D=2) with builtin time reversal invariance; 
 
%% prep stage

narginchk(1,2);
sysname = inputname(1);
if ~(isfield(sys,'run') && isfield(sys.run,'dt'))
	error('no information on time stepping from run.dt field');
end
dt = sys.run.dt;
if nargin == 2 
	if isfield(sys.run,'tspan')
		disp('superseding evolution time span in run.tspan with second input');
	end
	tspan = t;
elseif isfield(sys.run,'tspan')
	tspan = sys.run.tspan;
else
	error('evolution time span not set in second input nor in run.tspan field');
end
if isscalar(tspan)
	tspan = [0,tspan];
else
	tspan = tspan(1:2);
end
Dt = tspan(2)-tspan(1);
nt = floor(abs(Dt)/dt);
dtres = abs(Dt) - nt*dt;

Ustep = mkfactors(sys,sign(Dt)*dt);

psi = sys.psi;
if isfield(sys.grid,'a') 
	a = sys.grid.a; %#ok<NASGU>
end
BC = sys.grid.BC;
B = 0;
if isfield(sys,'mag') && isfield(sys.mag,'B')
	B = sys.mag.B;
end
if isfield(sys,'show')
	nshow = sys.show.n;
    if isfield(sys.show,'h')
        for jh = 1:size(sys.show.h,1)
            if isvalid(sys.show.h(jh))
                figure(sys.show.h(jh).Parent.Parent);
            end
        end
    end
end
record = isfield(sys,'record');
box = sys.grid.box;
D = length(box)/2;

rflag = 0;
if isfield(sys.run,'renorm')
	rflag = sys.run.renorm;
end
pflag = 0;
if isfield(sys.run,'project') && isfield(sys,'store');
	pflag = sys.run.project;
	storedpsi = sys.store.psi;
end

%% adapt to boundary conditions

ffthx = @fft;
ffthy = @fft;
iffthx = @ifft;
iffthy = @ifft;
if BC(1) == 1		% Dirichlet on x
	disp('using dsinft on x')
	ffthx = @dsinft;
	iffthx = @dsinft;
end
if D == 2 && BC(2) == 1		% Dirichlet on y
	disp('using dsinft on y')
	ffthy = @dsinft;
	iffthy = @dsinft;
end

%% reduce to one dimension if D = 1

if D == 1
	pre = @pre_noB;
	onestep = @onestep_1D;
	post = @post_noB;
else
	%% speed up a bit if there is no magnetic field and no DBC
	if nnz(B) == 0 && BC(1) == 0 && BC(2) == 0 %use the noB calls
		W = Ustep.Wy.*Ustep.Wx;
		pre = @pre_noB;
		onestep = @onestep_noB;
		post = @post_noB;
	else
		pre = @pre_full;
		onestep = @onestep_full;
		post = @post_full;
	end
end

%% routine core

if ~isfield(sys.run,'t')
	sys.run.t = tspan(1);
end
if record, do_record(0); end
feval(pre);
for n=1:nt
	feval(onestep);
	sys.run.t = sys.run.t + sign(Dt)*dt;
	if rem(n,nshow) == 0
		feval(post);
		sys.psi = psi;
		show(sys);
		feval(pre);
	end
	if record, do_record(n); end
end
if dtres > 0
	Ustep = mkfactors(sys,sign(Dt)*dtres);
	feval(onestep);
	sys.run.t = sys.run.t + sign(Dt)*dtres;
end
feval(post);

if rflag; renorm_; end
if pflag; psi = project(psi,storedpsi); end
sys.psi = psi;

if nshow > 0
	show(sys);
end

if nargout == 0
	assignin('caller',sysname,sys);
end

%% nested private functions doing pre, single step and post

	function pre_noB
		psi = psi.*Ustep.Vsqrt;
    end

    function pre_full
        psi = psi.*Ustep.Vsqrt./Ustep.G;
        psi = ffthy(psi);
        psi = iffthy(psi.*Ustep.Wysqrt);
    end

    function post_noB
        psi = psi./Ustep.Vsqrt;
    end

    function post_full
        psi = ffthy(psi);
        psi = iffthy(psi./Ustep.Wysqrt);
        psi = psi./Ustep.Vsqrt.*Ustep.G;
    end

    function onestep_noB
        psi = fft2(psi);
        psi = ifft2(psi.*W);
        psi = psi.*Ustep.V;
		if rflag; renorm_; end
		if pflag; psi = project(psi,storedpsi); end
    end

    function onestep_full
        psi = psi.*Ustep.G2;
        psi = ffthx(psi.');
		psi = iffthx(psi.*Ustep.Wx.').';
        psi = psi./Ustep.G2;
        psi = ffthy(psi);
        psi = iffthy(psi.*Ustep.Wy);
		if rflag; renorm_; end
		if pflag; psi = project(psi,storedpsi); end 
    end

    function onestep_1D
        psi = fft(psi);
        psi = ifft(psi.*Ustep.Wx);
        psi = psi.*Ustep.V;
        if rflag > 0; renproj_; end
    end

    function renorm_
		psi = psi/sum(sum(abs(psi).^2));
	end


	function do_record(n)
		fnames = fieldnames(sys.record);
		for j = 1:length(fnames)
			name = fnames{j};
			obs = sys.record.(name);
			if rem(n,obs.ndt) == 0
				feval(post);
				newvalues = eval(obs.expr);
				feval(pre);
				if n ==0 
					obs.values = newvalues;
					obs.t(1) = sys.run.t;
				else
					ndim = nnz(size(newvalues) > 1) + 1;
					obs.values = cat(ndim,obs.values,newvalues);
				end
				n = n/obs.ndt;
				obs.t(n+1) = sys.run.t;
			end
			sys.record.(name) = obs;
		end
	end

end
