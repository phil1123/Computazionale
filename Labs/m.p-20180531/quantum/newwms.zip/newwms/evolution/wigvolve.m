function sys = wigvolve(sys,t)
%
%% prep

narginchk(2,2);
sysname = inputname(1);
if ~isfield(sys,'w')
	error('no w field in first arg, quitting...')
end
if ~isa(sys.V,'function_handle')
	error('potential sys.V must be a function handle')
end
x = sys.grid.x;
k = sys.grid.y;
w = sys.w.';
dx = x(1,2)-x(1,1);
dt = sys.run.dt;
	
if isfield(sys,'show')
	nshow = sys.show.n;
end

ux = k(:,1)'*(dt/dx);
y = x'-dx;
%uk = exp(-1i*dt*ifftshift(sys.V(x+y/2) - sys.V(x-y/2)));
uk0 = ifftshift(sys.V(x+y/2) - sys.V(x-y/2));

n = 128;
nn = 127;
uk = -dx*[0:nn,-n:-1]'*x(1,:);

%% main

sys.run.t = 0;
w = fftadvect(w,ux/2,1);
for j = 1:floor(t/dt)
%	w = ifft(uk.*fft(w.')).';
	w = fftadvect(w.',uk,1).';
	w = fftadvect(w,ux,1);
	sys.run.t = sys.run.t + dt;
	if rem(j,nshow) == 0
		w = fftadvect(w,-ux/2,1);
		sys.w = w.';
		show(sys,sysname);
		w = fftadvect(w,ux/2,1);
	end
end
w = fftadvect(w,-ux/2,1);

sys.w = w.';
if nshow > 0
	show(sys,sysname);
end

if nargout == 0
	assignin('caller',sysname,sys);
end


