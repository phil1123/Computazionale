function U = mkfactors(sys,tau)

	box = sys.grid.box;
	D = length(box)/2;
	V = evalpotential(sys);
	if D == 2
		[ny,nx] = size(sys.psi);
		dx = sys.grid.x(1,2) - sys.grid.x(1,1);
		dy = sys.grid.y(2,1) - sys.grid.y(1,1);
	else
		[nx,nw] = size(sys.psi);
		dx = sys.grid.x(2) - sys.grid.x(1);
		if size(V,2) == 1
			V = V*ones(1,size(sys.psi,2));
		end
	end

	BC = sys.grid.BC;
	mass = 1;
	if isfield(sys,'mass')
		mass = sys.mass;
	end
	A = [];
	if isfield(sys,'mag')
		A = sys.mag.A;
		gfun = sys.mag.gfun;
	end
	
    Vb = real(V);
    % antialiasing
    Vb = min(Vb,pi/min(abs(tau)));
    Vb = max(Vb,-pi/min(abs(tau)));
    Vb = Vb + 1i*imag(V);

	if BC(1) == 1
        px = (pi/nx/dx)*(1:nx);
    else
		px = (1/dx)*skwavenums(nx);
	end
	if D == 2
		if BC(2) == 1
			py = (pi/ny/dy)*(1:ny);
		else
			py = (1/dy)*skwavenums(ny);
		end
		[px,py] = meshgrid(px,py);
	else
		px = px'*ones(1,nw);
		py = zeros(size(px));
		mass(2) = mass;
	end
    
	if isempty(A)
		[Kx,Ky] = kinenergy(px, py, mass);
	else
		[Kx,Ky] = kinenergy(px-2*A.ox, py-2*A.oy, mass);
	end
	
    U.V = exp(-1i*Vb*tau);
    U.Vsqrt = exp(-1i*Vb*tau/2);    
    U.Wx = exp(-1i*Kx*tau);
    U.Wy = exp(-1i*Ky*tau);
    U.Wysqrt = exp(-1i*Ky*tau/2);
    
	if ~isempty(A)
		U.G2 = exp(2*1i*gfun);
		U.G = exp(1i*gfun);
	end
    
    
