function f = rectanglarea(sys,x1,y1,x2,y2)

	x = sys.grid.x;
	y = sys.grid.y;
	x0 = (x1+x2)/2;
	y0 = (y1+y2)/2;
	dx = x2-x1;
	dy = y2-y1;
    f = (abs(x-x0) <= dx/2) .* (abs(y-y0) <= dy/2);
