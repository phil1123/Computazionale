% Potential barrier with head at "head()" and width 2*"thick"

function f = Barrier(x, y, thick,  head, dir)
  
  f =  (abs(x-head(1))<thick).*(y*dir>head(2));