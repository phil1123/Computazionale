function g = lpdiff2r(g,a)

g = (g([2:end,1],:) + g([end,1:end-1],:) - 2*g)/a/a;
