function f = frand(x,ks,seed)

	if nargin == 4
		s = RandStream('mt19937ar','Seed', seed);
		RandStream.setDefaultStream(s);
	end
    [nr,nc] = size(x);
    kx = skwavenums(nc);
    ky = skwavenums(nr);
    [kx,ky] = meshgrid(kx,ky);    
    f = fft2(rand(nr,nc));
    f = ifft2(f.*ks(kx,ky));       
