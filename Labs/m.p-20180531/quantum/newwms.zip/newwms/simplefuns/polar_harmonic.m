function jkm = polar_harmonic(sys,k,m)
  
	x = sys.grid.x;
	y = sys.grid.y;
    [phi,r] = cart2pol(x,y);
    jkm = besselj(abs(m),k*r) .* exp(1i*m*phi);
