function b = ball(sys,x0,y0,r)

	x = sys.grid.x;
	y = sys.grid.y;
	b = (x-x0).^2 + (y-y0).^2 < r^2;
