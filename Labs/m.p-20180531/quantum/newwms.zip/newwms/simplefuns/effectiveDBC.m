function V = effDBC

    global L x y dt
    V = Rectangle(x,y,L(1),L(2));
    V = V - Rectangle(x,y,L(1)-8,L(2)-8);
    V = pi*V/dt;