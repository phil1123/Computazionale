function f = frandn(sys,ks,seed)

if nargin == 3
	rng(seed);
end
gr = addskwn(sys.grid);
D = length(gr.box)/2;
if D == 2
	f = fft2(randn(size(gr.x)));
	f = ifft2(f.*ks(gr.kx,gr.ky));
else
	f = fft(randn(size(gr.x)));
	f = ifft(f.*ks(gr.k));
end	

