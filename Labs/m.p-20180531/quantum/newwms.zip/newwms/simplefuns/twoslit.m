function V = twoslit(sys,x0,thickness,width,separation)

	box = sys.grid.box;
	
    r = thickness/2;
    d = max(0, separation - width - 2*r);
	y1 = (separation + width)/2 + r;
    Vu = ball(sys,x0,y1,r) | rectanglarea(sys,x0-r,y1,x0+r,box(4));
    Vd = flipud(Vu);
    Vm = ball(sys,x0,d/2,r) | ball(sys,x0,-d/2,r);
    Vm = Vm | rectanglarea(sys,x0-r,-d/2,x0+r,d/2);
	V = Vu + Vm + Vd;
