qw = basesys1D(256,1);
x = qw.grid.x;
N = size(x);
L = qw.grid.box(2)-qw.grid.box(1);

sx = 1/2;
qw.psi = exp(-0.5*(x/sx).^2);
lam = 0.25;
qw.V = @(x)x.^2/2;
%qw.V = @(x)x.^2/2+lam*x.^4/4;
%qw.V = x.^2/2+lam*x.^4/4;
qw.show.V = 1;
a = qw.grid.box(2)/4;
translate(qw,a);

disp('press any key to begin')
pause

[~,qw] = wigner(qw);
show(qw)
ylim([-15,15])
zlim([-20,20])
view(2)

% disp('press any key to start evolution')
% pause
% evolve(qw,10);
