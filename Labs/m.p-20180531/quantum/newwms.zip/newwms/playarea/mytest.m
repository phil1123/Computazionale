function sys = mytest(n)

box = [-12,12];
N = [8192, 2*n+1];
dt = 0.002;
BC = 0;
wshow{1} = 'fftsmear(sum(abs(psi).^2,2),0.01)';
nshow = 5;

L = box(2)-box(1);
k = (2*pi/L)*(-n:n);
sys.grid = mkgrid(N,box,BC);
sys.grid.a = L/N(1);
x = sys.grid.x;
psi = sqrt(1/L)*exp(1i*(ones(N(1),1)*k).*x);
V = -cos(2*pi*x/L);

sys.psi = psi;
sys.V = V;

sys.run.dt = dt;
sys.run.t = 0;

sys.show.what = wshow;
sys.show.n = nshow;
sys.show.D = 1;
sys.show.ylim = [8,9];

ndt = 10;
expr = 'sum(abs(psi).^2.*lpdiff2r(abs(psi),a),2)./sum(abs(psi).^2,2)';
sys.record.ratio.ndt = ndt;
sys.record.ratio.expr = expr;

