% 1D quartic anharmonic oscillator
nw = 1;
q = basesys1D(nw);
x = q.grid.x;

% %sx = (1/4)*(1:size(x,2));
% sx = (1/4)*ones(1,size(x,2));
% q.psi = exp(-0.5*(x(:,1)*(1./sx)).^2);
% a = 4.25*linspace(-1,1,size(x,2));
% translate(q,a);

N = size(x);
L = q.grid.box(2)-q.grid.box(1);
p = (N(1)/L) * skwavenums(N(1));
q.psi = exp(1i*x(:,1)*p(1:nw));
show(q)

lam = 0.25;
q.V = x.^2/2+lam*x.^4/4;
disp('press any key to start evolution')
pause
% evolve(q,10);
% disp('press any key to continue evolution')
% pause
% show([])
q.show.what{1} = 'sum(abs(psi).^2,2)';
evolve(q,10);
